
This is a native, 64-bit version of Unreal Tournament 2004 for Win64
 (or "Windows XP 64-bit Edition", or "Windows for x64", etc).

To install:
 - Install the retail version of UT2004 on Win64 from the retail disc(s).
   The free demo version will not be sufficient for this. The installer
   on the disc is a 32-bit program, but it will run fine on Win64.
 - Patch the installation to version 3369 (available from
   http://www.unrealtournament.com/). The update program is also 32-bit
   but, again, will run fine on win64.
 - Unpack this .zip file into the directory where you installed the
   game, so that "ut2004-win64.exe" ends up in the game's "System"
   directory, "ut2004-win64Logo.bmp" ends up in "Help", etc...
 - Run the ut2004-win64.exe program from the game's "System" directory.


Minimum System Specs for 64-Bit Version:
Supported OS: Windows� XP, Windows� XP Professional x64 Edition
Processor: AMD Athlon� 64 processor 2800+ or equivalent
RAM: 128MB
Video Card: 64MB DirectX� 9.0 compatible graphics card
Sound Card: DirectX 9.0 compatible PCI card
DirectX Version: DirectX 9.0 included with 64-bit OS
CD-ROM: 6X DVD or 16X CD-ROM
Hard Drive Space: 5.6 GB Free (for both retail version & 64-bit version)
Multiplay: 33.6 Kps modem for LAN/Internet play

 
Recommended System Specs for 64-Bit Version:
Supported OS: Windows� XP, Windows� XP Professional x64 Edition
Processor: AMD Athlon� 64 processor 3400+ or equivalent
RAM: 256MB
Video Card: 128MB DirectX 9.0 compatible graphics card
Sound Card: Sound Blaster� Audigy series recommended
DirectX Version: DirectX 9.0 included with 64-bit OS
CD-ROM: 24X DVD or 24X CD-ROM
Hard Drive Space: 5.6 GB Free (for both retail version & 64-bit version)
Multiplay: Broadband Internet connection recommended

* Note: Please see retail box for 32-bit OS system recommendations.


Other notes:

The Win64 version includes both a Direct3D9 and OpenGL renderer.
 The Direct3D 8 renderer (the default on win32) is not available, nor
 is the Pixomatic software renderer.
 
The 32-bit version is still available on your system, and should not
 be affected by the existance of the 64-bit version. They even use
 seperate .ini files by default.

ucc-win64.exe is the 64-bit version of the dedicated server.

There is no support available for the 64-bit version of the game.
 Please do not contact Atari tech support about the Win64 version.

Enjoy!

--Epic Games.

